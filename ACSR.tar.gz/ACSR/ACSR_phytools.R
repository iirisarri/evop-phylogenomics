#install.packages("phytools")
library("phytools")

setwd("")

tree<-read.newick("partitioned.treefile.rooted.nw.tre")

plot(tree, show.tip.label = TRUE)

# Load trait data
trait_data <- read.table("multicellularity.txt", row.names = 1)

# Extract trait vector
trait <- trait_data[,1]

# Convert to factor (important for discrete traits)
trait <- as.factor(trait)

# Run ancestral state reconstruction using ML
fit <- ace(trait, tree, type = "discrete", model = "ER")

# View likelihoods at nodes
fit$lik.anc

# Plot results
cols<-c("#FFBE0B", "#8338EC")

plot(tree, show.tip.label = TRUE)

nodelabels(pie = fit$lik.anc, piecol = cols, cex = 0.6)

tiplabels(pie = to.matrix(trait, levels(trait)),
          piecol = cols, cex = 0.4)

# Add legend
legend("topleft", legend = levels(trait),
       fill = cols, cex = 0.8)

